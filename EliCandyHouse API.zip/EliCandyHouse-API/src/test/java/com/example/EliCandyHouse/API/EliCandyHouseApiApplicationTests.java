package com.example.EliCandyHouse.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EliCandyHouseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
